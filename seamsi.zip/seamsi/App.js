import React, { Component, useState, useEffect } from 'react';
import { Text, View, StyleSheet, Button, Animated, Alert,TouchableOpacity, Vibration, Platform } from 'react-native';
import Constants from 'expo-constants';
import { DangerZone } from 'expo';
import { DeviceMotion } from 'expo-sensors';
import { withAnchorPoint } from 'react-native-anchor-point';
import box from './assets/box.png';
import * as Haptics from 'expo-haptics';
 import AlertAsync from "react-native-alert-async";
// You can import from local files

export default class DeviceMotionExample extends Component {

  state = {
    motionData: null,
    stack: 0,
    selected: true,
    result: ""
  };
  
  componentDidMount() {
    this.slow;
    DeviceMotion.addListener(motion => {
      this.setState({ motionData: motion });
      console.log(motion)
    });
  }

  

  slow = () => {
    DeviceMotion.setUpdateInterval(500);
  }
  
  componentWillUnmount() {
    DeviceMotion.removeAllListeners();
  }

  
    resetval = () => {
      var myArray = [
      "Good luck!!!!\nPogggg",
      "Natural luck\npog",
      "Bad luck :( \nUnpog"
      ];
      var randomItem = myArray[Math.floor(Math.random()*myArray.length)];
      
      if (this.state.result == "")
          this.setState({result: randomItem})
      this.setState({selected: true})
    }

    resetval2 = () => {

      this.setState({result: "", selected: true, stack: 0})
    }
  
  render() {

    const vibrate = () => {
    if (Platform.OS === "ios") {
      // this logic works in android too. you could omit the else statement
      const interval = setInterval(() => Vibration.vibrate(), 1000);
      // it will vibrate for 5 seconds
      setTimeout(() => clearInterval(interval), 5000);
    } else {
    
      Vibration.vibrate(1000);
    }
  };

    function calibrate(x,y){
        let transform = {
        transform: [{ perspective: 400 }, { rotate: -x + 'rad' }, {rotateX: -y}],
    };
    return withAnchorPoint(transform, { x: 0.5, y: 0.8 }, { width: 200, height: 200 });
    }
    
   let x = 0;
   let y = 0;
   let accx = 0;
   let accy = 0;
   let res = 0;

    if(this.state.motionData && this.state.motionData.rotation)
    {
        x = this.state.motionData.rotation.alpha 
        y = this.state.motionData.rotation.beta 
        accx = this.state.motionData.acceleration.x
        accy = this.state.motionData.acceleration.y

        if (accx < 0)
            accx *= -1
        if (accy < 0)
            accy *= -1

        res =  accx/2 + accy;
        if (res > 5 )
        {
           this.state.stack += 1;
        }
        if (this.state.stack > 10)
        {
          if(this.state.stack == 11){
            Vibration.vibrate();
          }
          this.state.selected = false;
        }
    }
    return (
      <View style={styles.container}>
      <Animated.Image style={[calibrate(x,y)]} source={box} />
     
      {!this.state.selected ? (<View>
          <TouchableOpacity
          style={styles.textb2} 
          onPress={() => {this.resetval() ;}}>
          <Text> Result ready </Text>
          </TouchableOpacity>
          </View>
          ) : (
          <View>
          <Text>Shake it up!!</Text>
          </View>
          )}


          {this.state.result != "" ? (<View>
          <View style={[styles.blockBlue]} >
          <Text style={[styles.textshow]}>Your result is : {this.state.result}</Text>
          </View>
          <Button
          title="reset"
          style={{
            width: 180,
            elevation: 3,
          }}
          onPress={this.resetval2}
          /></View>
          ) : (
          <View>
          
          </View>
          )}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
  },
  blockBlue: {

    height: 190,
    width: 300,
    backgroundColor: '#cc232a',
    borderBottomLeftRadius: 15,
            borderBottomRightRadius: 15,
            borderTopRightRadius: 2,
            borderTopLeftRadius: 2,
            overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center'
  },
  textshow: {
    fontSize: 20,
    fontWeight: "bold",
    color: 'white',
    textAlign: 'center'
  },
  textb2: {
    height: 50,
    width: 300,
    backgroundColor: '#ffd84b',
    borderBottomLeftRadius: 2,
            borderBottomRightRadius: 2,
            borderTopRightRadius: 15,
            borderTopLeftRadius: 15,
            overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center'
  }
});