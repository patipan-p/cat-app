import { firebase } from '@firebase/app';
import '@firebase/firestore';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAFqGxiVjq9XEyky3GsL4XCSe4nWCV8ikE",
  authDomain: "meoow2.firebaseapp.com",
  projectId: "meoow2",
  storageBucket: "meoow2.appspot.com",
  messagingSenderId: "37371417098",
  appId: "1:37371417098:web:3b29969b2c02b24fc545f3"
};

firebase.initializeApp(firebaseConfig);

var firestore = firebase.firestore();

export default firestore;
