import { StyleSheet, Text, View, Button,Image, ScrollView, TouchableHighlight, TouchableOpacity, Platform, TextInput} from 'react-native';
import React, { useState, useEffect } from 'react';

import { firebase } from '@firebase/app';
import firestore from '../Firestore';
import '@firebase/auth';
import '@firebase/storage';


function register({navigation}){

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  async function Register(){
    await firebase
      .auth()
      .createUserWithEmailAndPassword(email, password)
      .then((user) => {
        console.log(user);
        let collRef = firestore.collection('user').doc(user.user.uid);
        collRef.set({
          name: name,
        });
        alert('Register complete')
        navigation.reset({index: 0, routes: [{name : 'login'}]});
      })
      .catch((error) => {
        alert(error.message);
      });
  }
    

  return (
    <View style={styles.container}> 
      <View style={styles.loginbox}>
        <TextInput placeholder='Username' style={styles.textInput} onChangeText={setName}/>
        <TextInput placeholder='Email' style={styles.textInput} onChangeText={setEmail}/>
        <TextInput placeholder='Password' style={styles.textInput} onChangeText={setPassword} secureTextEntry/>
      <TouchableOpacity onPress={() => Register()}>
          <View style={styles.button}>
            <Text>Register</Text>
          </View>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.goBack()}>
          <View style={styles.button}>
            <Text>Cencel</Text>
          </View>
      </TouchableOpacity>
      </View>
    </View>
  );
}

export default register;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#A9D3C9'
  },
  loginbox: {
    paddingHorizontal: 20
  },
  button: {
    alignItems: "center",
    backgroundColor: "#FFE5B8",
    paddingVertical: 10,
    marginTop: 10
  },
  textInput: {
    padding: 10
  },
  
})