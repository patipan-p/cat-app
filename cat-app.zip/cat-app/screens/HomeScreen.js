import { StyleSheet, Text, View, Button,Image, ScrollView, TouchableHighlight, TouchableOpacity, Platform, TextInput} from 'react-native';
import React, { useState, useEffect } from 'react';

import { firebase } from '@firebase/app';
import firestore from '../Firestore';
import '@firebase/auth';
import '@firebase/storage';


//screen
import Home from './innerScreens/Home'
import Meowpedia from './innerScreens/Meowpedia'
import Map from './innerScreens/Map'
import Profile from './innerScreens/Profile'


//import navigator
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

//create bottom tab
const Tab = createBottomTabNavigator();
//create stack
const Stack = createStackNavigator();


import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons';

function home({navigation}){

 

  return (
    <Tab.Navigator screenOptions={{ headerShown: false }}>
      <Tab.Screen
        name="Home"
        component={Home}
        options={{
          tabBarLabel: 'Home',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="home" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Meowpedia"
        component={Meowpedia}
        options={{
          unmountOnBlur: true,
          tabBarLabel: 'Meowpedia',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="cat" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Map"
        component={Map}
        options={{
          tabBarLabel: 'Map',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="map" color={'red'} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Profile"
        component={Profile}
        options={{
          tabBarLabel: 'Profile',
          tabBarIcon: ({ color, size }) => (
            <FontAwesome name="user" color={color} size={size} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default home;

const styles = StyleSheet.create({
  
})