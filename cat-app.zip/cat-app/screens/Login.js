import { StyleSheet, Text, View, Button,Image, ScrollView, TouchableHighlight, TouchableOpacity, Platform, TextInput} from 'react-native';
import React, { useState, useEffect } from 'react';

import { firebase } from '@firebase/app';
import firestore from '../Firestore';
import '@firebase/auth';
import '@firebase/storage';


function login({navigation}){

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  async function Login(){
    await firebase
      .auth()
      .signInWithEmailAndPassword(email, password)
      .then((user) => {
        alert('success');
        navigation.reset({index: 0, routes: [{name : 'home'}]});
      })
      .catch((error) => {
        alert("Login failed ()");
        //navigation.reset({index: 0, routes: [{name : 'home'}]});
      });
  }

  return (
    <View style={styles.container}>
    <Image source={require('./logo.png')} style={{height: 200, width: 200, alignSelf: 'center'}}/> 
      <View style={styles.loginbox}>
        <TextInput placeholder='Email' style={styles.textInput} onChangeText={setEmail}/>
        <TextInput placeholder='Password' style={styles.textInput} onChangeText={setPassword} secureTextEntry/>
      <TouchableOpacity onPress={() => Login()}>
          <View style={styles.button}>
            <Text>Login</Text>
          </View>
      </TouchableOpacity>
      <View style={styles.inline}>
      <TouchableOpacity onPress={() => navigation.navigate('register')} style={styles.right}>
          <View style={styles.reg}>
            <Text style={styles.regtext} >wanna join? register.</Text>
          </View>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('forgot')} style={styles.left}>
          <View style={styles.reg}>
            <Text style={styles.regtext}>forgot your password?</Text>
          </View>
      </TouchableOpacity>
      </View>
      </View>
    </View>
  );
}

export default login;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#A9D3C9'
  },
  loginbox: {
    paddingHorizontal: 20
  },
  button: {
    alignItems: "center",
    backgroundColor: "#FFE5B8",
    paddingVertical: 10,
    marginTop: 10
  },
  textInput: {
    padding: 10
  },
  reg: {
    
    alignItems: "center",
  },
  regtext: {
    textAlign: 'center',
    fontStyle: 'italic',
    fontSize: 12,
    textDecorationLine: 'underline',
  },
  inline: {
    marginTop: 10,
    display: 'inline-block',
  },
  left: {
    float: 'left'
  },
  right: {
    float: 'right'
  }
})