import React, { useState, useEffect } from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { GoogleMap, useJsApiLoader, useLoadScript, Marker, InfoWindow } from '@react-google-maps/api';

const containerStyle = {
  width: '100%',
  height: '100%'
};


const center = {
  lat: 0,
  lng: 0
};

function MyComponent({navigation}) {
  const [selected, setSelected] = useState(null)
  const [data, setData] = useState([]);
  const [lat, setLat] = React.useState(0);
  const [lng, setLng] = React.useState(0);

  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: "AIzaSyCkZSQMFeKPFuHV1pW4lpXI055lk_NFHP8"
  })

  

  const [map, setMap] = React.useState(null)

  async function select(){
  const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': '16f6436908mshca72971e4b218dcp13c745jsna1c8892924f8',
		'X-RapidAPI-Host': 'google-maps28.p.rapidapi.com'
	}
  };

  await fetch('https://google-maps28.p.rapidapi.com/maps/api/place/nearbysearch/json?location=' + lat + '%2C' + lng + '&radius=500000&language=en& type=pet_store', options)
	.then(response => response.json())
	.then(response => setData(response.results))
	.catch(err => console.error(err));
  console.log(data)
  }


  
  useEffect(()=> {
    navigator?.geolocation.getCurrentPosition(
      ({ coords: { latitude: lat2, longitude: lng2 } }) => {
        setLat(lat2)
        setLng(lng2)
    })
    setMap(map)
    select()
  }, [lat,lng])

  const onUnmount = React.useCallback(function callback(map) {
    setMap(null)
  }, [])

  async function openApp(it){
    const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': '16f6436908mshca72971e4b218dcp13c745jsna1c8892924f8',
		'X-RapidAPI-Host': 'google-maps28.p.rapidapi.com'
	}
};

  await fetch('https://google-maps28.p.rapidapi.com/maps/api/place/details/json?fields=address_component%2Cadr_address%2Cbusiness_status%2Cformatted_address%2Cgeometry%2Cicon%2Cicon_mask_base_uri%2Cicon_background_color%2Cname%2Cpermanently_closed%2Cphoto%2Cplace_id%2Cplus_code%2Ctype%2Curl%2Cutc_offset%2Cvicinity%2Cformatted_phone_number%2Cinternational_phone_number%2Copening_hours%2Cwebsite%2Cprice_level%2Crating%2Creview%2Cuser_ratings_total&place_id=' + it +'&language=en&region=en', options)
    .then(response => response.json())
	.then(response => window.open(response.result.url))
	.catch(err => console.error(err));
  }


  return isLoaded ? (
      <GoogleMap
        mapContainerStyle={containerStyle}
        zoom={16}
        onUnmount={onUnmount}
        center={{lat,lng}}
        
      >
        <Marker position={{lat,lng}} />
        {data.map((e)=>(
          <Marker icon={{
            // path: google.maps.SymbolPath.CIRCLE,
            url: ('https://img.icons8.com/external-those-icons-fill-those-icons/24/000000/external-pin-maps-and-locations-those-icons-fill-those-icons-1.png'),
            fillColor: '#EB00FF',
            scaledSize: new window.google.maps.Size(30,30),
        }}  position={e.geometry.location} 
        onClick={() => {
          setSelected(e)
        }}/>
        ))}

        {selected && (
          <InfoWindow position={selected.geometry.location} 
          onCloseClick={()=> setSelected(null)} > 
          <Text > {selected.name} {selected.rating}</Text>
          </InfoWindow>
        )
        }
      </GoogleMap>
  ) : <></>
}

export default React.memo(MyComponent)