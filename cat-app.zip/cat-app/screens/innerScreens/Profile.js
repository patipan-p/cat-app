import { StyleSheet, Text, View, Button,Image, ScrollView, TouchableHighlight, TouchableOpacity, Platform, TextInput} from 'react-native';
import React, { useState, useEffect, Component } from 'react';

import _ from "lodash";


import { firebase } from '@firebase/app';
import firestore from '../../Firestore';
import '@firebase/auth';
import '@firebase/storage';

import Edit from './Profile/Edit'

import Save from './Profile/Saved'

import ReactDOM from 'react-dom';
//import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
//import { Carousel } from 'react-responsive-carousel';

//import navigator
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

//create bottom tab
const Tab = createBottomTabNavigator();
//create stack
const Stack = createStackNavigator();


import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons';

function Mp({navigation}){

  const [cuser, setCuser] = useState('')
  const [name, setName] = useState('');
  const [image, setImage] = useState('');

  async function getImage(){
    const result = await fetch(
      "https://api.thecatapi.com/v1/images/search" , {
      headers: {
        "Content-Type": "application/json",
        "x-api-key": "eee23f35-b735-4472-a661-1af69728d177 "}}
    )
    const json = await result.json();
    if (json.length > 0) {
      setImage(json[0].url)
    }
  }

  useEffect(() => {
    async function CheckLogin() {
      firebase.auth().onAuthStateChanged((user) => {
        if (user) {
          setCuser(user);

          const docRef = firestore.collection('user').doc(user.uid);

          docRef.get().then((doc) => {
            setName(doc.data().name);
          });

          let storageRef = firebase.storage().ref();
          let picRef = storageRef.child(user.uid + '.jpg').getDownloadURL();
          if (!picRef)
          {  getImage()}
          else
          {
            picRef.then((url) => setImage(url));
          }
        }
      });
    }
    CheckLogin();
  }, [])

  async function Logout(){
    alert('logout')
    await firebase.auth().signOut();
    navigation.reset({ index: 0, routes: [{ name: 'login' }] });
  }
  return (
    <View style={styles.container}>
      <View style={styles.upbar}>
      <Text style={{opacity: 0}}> Hello there </Text>
        <Image style={styles.image}source={{uri:image}} />
      </View>
      <View style={styles.username}>
        <Text style={styles.username_name}> {name} </Text>
      </View>
      <View style={{marginTop: 15}}>
      <View style={styles.btc} >
      <TouchableOpacity onPress={()=> navigation.navigate('Edit')}>
        <View style={styles.button}>
          <Text> Edit profile </Text>
        </View>
      </TouchableOpacity>
      </View>
      <View style={styles.btc} >
      <TouchableOpacity onPress={()=> navigation.navigate('Saved')}>
        <View style={styles.button}>
          <Text> Saved Content </Text>
        </View>
      </TouchableOpacity>
      </View>
      </View>
      <View style={styles.btc2} >
      <TouchableOpacity onPress={()=> Logout()}>
        <View style={styles.buttonLong}>
          <Text> Logout </Text>
        </View>
      </TouchableOpacity>
      </View>
      
    </View>
  );
}

function Main({navigation}){
  return(
  <View style= {styles.container}>
        <Stack.Navigator screenOptions={{
    headerShown: false
  }}>
        <Stack.Screen name="Main" component={Mp}/>
        <Stack.Screen name="Edit" component={Edit}/>
        <Stack.Screen name="Saved" component={Save}/>
        </Stack.Navigator>   
    </View>
)}

export default Main;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    height: '100%',
    backgroundColor: '#BAE2DD'
  },
  image: {
      resizeMode: 'fit',
      width: '100%',
      height: '100%',
      borderRadius: 10,
  },
  upbar: {
    justifyContent: 'top',
    width: '100%',
    height: 200,
    backgroundColor: 'pink',
    padding: 10,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
  },
  btc: {
    paddingHorizontal: 10,
    paddingTop: 10,
    width: '100%',
    justifyContent: 'center'
  },
  btc2: { 
    width: '100%',
    paddingHorizontal: 10,
    flex: 1,
    justifyContent: 'flex-end',
    marginBottom: 5,
    
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: 50,
    backgroundColor: '#FFFDD0',
    borderRadius: 5,
  },
  buttonLong: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: 50,
    backgroundColor: 'red',
    borderRadius: 8
  },
  username: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15
  },
  username_name: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    textShadowColor: 'black',
    textShadowRadius: 5
  }
  
})