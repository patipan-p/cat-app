import { StyleSheet, Text, View,Image, ScrollView, TouchableHighlight, TouchableOpacity, Platform, TextInput} from 'react-native';
import React, { useState, useEffect } from 'react';

import _ from "lodash";

import Button from '@mui/material/Button';

import { firebase } from '@firebase/app';
import firestore from '../../Firestore';
import '@firebase/auth';
import '@firebase/storage';

import Breed from '../../components/Breed'

//import navigator
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

//create bottom tab
const Tab = createBottomTabNavigator();
//create stack
const Stack = createStackNavigator();




import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons';

function Pediadetail({route, navigation}){
  const [data, setData] = useState([]);
  const [offset, setOffset] = useState(1);
  const [text, setText] = useState('');
  const { itemId } = route.params;
  const { image } = route.params;

  async function fetchData() {
    
    const result = await fetch(
      "https://api.thecatapi.com/v1/images/search?breed_ids=" + itemId, {
      headers: {
        "Content-Type": "application/json",
        "x-api-key": "eee23f35-b735-4472-a661-1af69728d177 "}}
    )
    const json = await result.json();
    if (json.length > 0) {
      setData(json)
      console.log(json)
    }   
  }

  function openWiki(){
    const url = data[0].breeds[0].wikipedia_url;
    window.open(url, '_blank');
    }

  useEffect (() => {
    fetchData()
  }, []);

  return (
    <ScrollView style={styles.container2}>
        {data.map((item) => (  
          <View style={styles.con2}>
          <Text style={{alignSelf: 'center', marginBottom: 15, fontWeight: 'bold'}}> {data[0].breeds[0].name} </Text>
          <Image style={styles.image}source={{uri:'https://cdn2.thecatapi.com/images/'+ data[0].breeds[0].reference_image_id +'.jpg'}} />
          <View style={{marginVertical: 15}}>       
          <Text>Origin: {data[0].breeds[0].origin} </Text>
          <Text>Temperament: {data[0].breeds[0].temperament} </Text>
          <Text>Description: {data[0].breeds[0].description} </Text>
          <Text>Life span: {data[0].breeds[0].life_span} years</Text>
          </View>
          <Button variant="outlined" onClick={() => openWiki()}>Wiki</Button>
          </View>         
        ))}
    </ScrollView>
  );
}

function Meowpedia({navigation}){
  const [data, setData] = useState([]);
  const [offset, setOffset] = useState(1);
  const [text, setText] = useState('');

  async function fetchData() {
    
    const result = await fetch(
      "https://api.thecatapi.com/v1/breeds", {
      headers: {
        "Content-Type": "application/json",
        "x-api-key": "eee23f35-b735-4472-a661-1af69728d177 "}}
    )
    const json = await result.json();
    
    if (json.length > 0) {
      setData([...data, ...json.map(e => ({ id: e.id, name: e.name , pic: e.image}))])
    }   
  }

  useEffect (() => {
    fetchData()
  }, []);

  return (
    <View style={styles.container}>
      <ScrollView style={{marginTop: 30}}>
        {data.map((item) => (
          _.toArray(item.pic).slice(3,4).map((key, value) => (
            <TouchableOpacity onPress={() => {navigation.navigate('Meowpedia', {
            screen: 'Detail',
            params: { itemId: item.id, image: key },
            })} }>
              <Breed name={item.name} pic={key} />
            </TouchableOpacity>
          ))          
        ))}
     
      </ScrollView> 
    </View>
  );
}

function mainp({navigation}){
  return(
     <Stack.Navigator screenOptions={{
    headerShown: false
  }}>
        <Stack.Screen name="Main" component={Meowpedia}/>
        <Stack.Screen name="Detail" component={Pediadetail}/>
        </Stack.Navigator>   
  )
}

export default mainp;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#BAE2DD'
  },
  container2: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#BAE2DD'
  },
  image: {
      resizeMode: 'cover',
      width: 250,
      height: 250,
      borderWidth: 5,
      borderRadius: 2,
      alignSelf: 'center',
  },
  con2: {
    
    padding: 10
  }
  
})