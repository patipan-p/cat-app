import { StyleSheet, Text, View, Button,Image, ScrollView, TouchableHighlight, TouchableOpacity, Platform, TextInput, ImageBackground} from 'react-native';
import React, { useState, useEffect, Component } from 'react';

import _ from "lodash";



//import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
//import { Carousel } from 'react-responsive-carousel';

//import navigator
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

//create bottom tab
const Tab = createBottomTabNavigator();
//create stack
const Stack = createStackNavigator();


import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons';

function Main({navigation}){

  const [img, setImg] = useState('')

  async function getImage(){
    const result = await fetch(
      "https://api.thecatapi.com/v1/images/search" , {
      headers: {
        "Content-Type": "application/json",
        "x-api-key": "eee23f35-b735-4472-a661-1af69728d177 "}}
    )
    const json = await result.json();
    if (json.length > 0) {
      setImg(json[0].url)
    }
  }

  useEffect(() => {
    getImage()
  }, [])
  return (
    <View style={styles.container}>
      <View style={styles.upbar}>
      <Text style={{opacity: 0}}> Hello there </Text>
        <Image style={styles.image}source={{uri:img}} />
      </View>
      <View style={styles.btc}>
      <TouchableOpacity style={styles.button} onPress={()=> navigation.navigate('Hotel')}>
      <ImageBackground source={'https://images.pexels.com/photos/320014/pexels-photo-320014.jpeg'} 
      resizeMode="cover" style={{width: '100%', height: '100%', justifyContent: 'center'}}>
          <Text style={styles.txt}> Cafe </Text>
          </ImageBackground>
      </TouchableOpacity> 
      <TouchableOpacity style={styles.button} onPress={()=> navigation.navigate('Cafe')}>  
      <ImageBackground source={'https://images.pexels.com/photos/1170986/pexels-photo-1170986.jpeg'} 
      resizeMode="cover" style={{width: '100%', height: '100%', justifyContent: 'center'}}>    
          <Text style={styles.txt}> Pet Shop </Text>
          </ImageBackground>
      </TouchableOpacity>
      </View>
      <View style={styles.btc2} >
      <TouchableOpacity onPress={()=> navigation.navigate('Adoption')}>
      <ImageBackground source={'https://images.pexels.com/photos/617278/pexels-photo-617278.jpeg'} 
      resizeMode="cover" style={styles.buttonLong}>
          <Text style={styles.txt}> Adoption </Text> 
        </ImageBackground>
      </TouchableOpacity>
      </View>
      <View style={styles.btc2} >
      <TouchableOpacity onPress={()=> navigation.navigate('Random')}>
        <ImageBackground source={'https://images.pexels.com/photos/669015/pexels-photo-669015.jpeg'} 
      resizeMode="cover" style={styles.buttonLong}>
          <Text style={styles.txt}>Random Cat Gallery </Text>
        </ImageBackground>
      </TouchableOpacity>
      </View>
      
    </View>
  );
}

export default Main;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'top',
    backgroundColor: '#BAE2DD'
  },
  image: {
      resizeMode: 'fit',
      width: '100%',
      height: '100%',
      borderRadius: 10,
  },
  upbar: {
    width: '100%',
    height: 200,
    backgroundColor: 'pink',
    padding: 10,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
  },
  button: {
    alignSelf: 'stretch',
    alignItems: 'center',
    justifyContent: 'center',
    width: '45%',
    height: '100%',
    backgroundColor: 'red',
    borderRadius: 8,
  },
  btc: {
    flex: 1,
    width: '100%',
    flexDirection: "row",
    marginTop: 20,
    justifyContent: 'space-evenly'
  },
  btc2: {
    width: '100%',
    paddingHorizontal: 10,
    marginTop: 10,
  },
  
  buttonLong: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: 100,
    borderRadius: 8
  },
  txt: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    alignSelf: 'center'
  }
  
})