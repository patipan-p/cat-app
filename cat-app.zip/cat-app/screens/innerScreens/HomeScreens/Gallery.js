import { StyleSheet, Text, View,Image, ScrollView, TouchableHighlight, TouchableOpacity, Platform, TextInput, FlatList} from 'react-native';
import React, { useState, useEffect, Component } from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import _ from "lodash";


import Button from '@mui/material/Button';


//import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
//import { Carousel } from 'react-responsive-carousel';
import Gallery from 'react-grid-gallery';
//import navigator
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

//create bottom tab
const Tab = createBottomTabNavigator();
//create stack
const Stack = createStackNavigator();
import ImageGrid from '../../../components/ImageGrid'

import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons';
import { firebase } from '@firebase/app';
import firestore from '../../../Firestore';
import '@firebase/auth';
import '@firebase/storage';

function Detail({route, navigation}){
  const [user,setUser] = useState('')
  const { itemId } = route.params;

  async function CheckLogin() {
      firebase.auth().onAuthStateChanged((user) => {
        if (user) {
          setUser(user);
      }})
  }

  function Fav(){
    console.log('start')
    let docRef = firestore.collection('user').doc(user.uid).collection('saved');
    docRef.add({
      url: itemId,
    }).then(
      alert("Added to favourite")
    );
  }
  useEffect(()=>{
    CheckLogin()
  })

  return (
    <View style={styles.scr2}>
      <Image style={{width: '80%', height: '80%', resizeMode: 'contain',}} source={{uri: itemId}} />
      <Button style={{marginTop: 10}} variant="contained" onClick={()=> Fav()}>Add to favourite</Button>
      <Button style={{marginTop: 5}} variant="contained" onClick={()=> navigation.goBack()}>Back</Button>
    </View>
  );
}

function Main2({navigation}){

  const [images, setData] = useState([])

  async function select(){

  //APISINOLONGERWORKING
  await fetch('https://cataas.com/api/cats?limit=60')
	.then(response => response.json())
	.then(response => setData(response.map((e)=> "https://cataas.com/cat/" + e.id)))
	.catch(err => console.error(err));
  }

  console.log(images)

  useEffect(() => {
    select()
  }, [])

  return (
    <ScrollView style={styles.scr}>
      <FlatList
        data={images}
        renderItem={(item) => {
        return <TouchableOpacity onPress={() => {navigation.navigate('Random', {
            screen: 'Detail',
            params: { itemId: item.item},
            }) }}>
                <ImageGrid pic={item.item}/>
               </TouchableOpacity>
        }}
        numColumns={3}
      />
    </ScrollView>
  );
}

function mainp({navigation}){
  return(
    <Stack.Navigator screenOptions={{
        headerShown: false
        }}>
        <Stack.Screen name="Main" component={Main2}/>
        <Stack.Screen name="Detail" component={Detail}/>
    </Stack.Navigator>   
  )
}

export default mainp;

const styles = StyleSheet.create({
  scr: {
    flex: 1,
    backgroundColor: '#BAE2DD'
  },
  scr2: {
    backgroundColor: '#BAE2DD',
    width: '100%',
    height: '100%',
    alignItems: 'center'
  },

})