import { StyleSheet, Text, View, Button,Image, ScrollView, TouchableHighlight, TouchableOpacity, Platform, TextInput} from 'react-native';
import React, { useState, useEffect, Component } from 'react';

import _ from "lodash";



//import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
//import { Carousel } from 'react-responsive-carousel';

//import navigator
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

//create bottom tab
const Tab = createBottomTabNavigator();
//create stack
const Stack = createStackNavigator();
import Obj from '../../../components/listObj'

import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons';

function Main({navigation}){

  const [data, setData] = useState([])

  async function select(){
  const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': '16f6436908mshca72971e4b218dcp13c745jsna1c8892924f8',
		'X-RapidAPI-Host': 'google-maps28.p.rapidapi.com'
	}
  };

  await fetch('https://google-maps28.p.rapidapi.com/maps/api/place/textsearch/json?query=pet%20shop&region=th&language=en', options)
	.then(response => response.json())
	.then(response => setData(response.results))
	.catch(err => console.error(err));
  console.log(data)
  }

  useEffect(() => {
    select()
  }, [])
  
  async function openApp(it){
    const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': '16f6436908mshca72971e4b218dcp13c745jsna1c8892924f8',
		'X-RapidAPI-Host': 'google-maps28.p.rapidapi.com'
	}
};

  await fetch('https://google-maps28.p.rapidapi.com/maps/api/place/details/json?fields=address_component%2Cadr_address%2Cbusiness_status%2Cformatted_address%2Cgeometry%2Cicon%2Cicon_mask_base_uri%2Cicon_background_color%2Cname%2Cpermanently_closed%2Cphoto%2Cplace_id%2Cplus_code%2Ctype%2Curl%2Cutc_offset%2Cvicinity%2Cformatted_phone_number%2Cinternational_phone_number%2Copening_hours%2Cwebsite%2Cprice_level%2Crating%2Creview%2Cuser_ratings_total&place_id=' + it +'&language=en&region=en', options)
    .then(response => response.json())
	.then(response => window.open(response.result.url))
	.catch(err => console.error(err));
  }
  return (
    <View style={styles.container}>
    <ScrollView style={{width: '100%'}}>
      {
        data.map((item) => (
          <TouchableOpacity onPress={() => openApp(item.place_id)}>
         <Obj name={item.name} pic={item.icon} address={item.formatted_address} rating={item.rating}/>
         </TouchableOpacity>
        ))
      }
    </ScrollView>
    </View>
  );
}

export default Main;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'top',
    alignItems: 'center',
    backgroundColor: '#BAE2DD'
  },
  topmenu: {
    top: 5,
    width: '90%',
    height: 50,
    display: 'inline-block',
    justifyContent: 'center',
    alignItems: 'center'
  },

})