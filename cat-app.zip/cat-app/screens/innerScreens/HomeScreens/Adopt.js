import { StyleSheet, Text, View, Button,Image, ScrollView, TouchableHighlight, TouchableOpacity, Platform, TextInput} from 'react-native';
import React, { useState, useEffect, Component } from 'react';

import _ from "lodash";

import Lob from '../../../components/listObj2'

//import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
//import { Carousel } from 'react-responsive-carousel';

//import navigator
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

//create bottom tab
const Tab = createBottomTabNavigator();
//create stack
const Stack = createStackNavigator();


import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons';
import { Client } from "@petfinder/petfinder-js";

//2023-06-05
const client = new Client({
  apiKey: 'SZ1pF8CJE21K5fAqjPwSfdS4c7yo7MGYyil8SH2u3s2bJ8QtGW',
  secret: 'TsBbhsSZKKeFG4dfUEOSp9OuvkKeCFhpjLvUB4XH'
});


function Main({navigation}){

  const [data, setData] = useState([])

  async function getD(){
    let searchTerm = {
      type: "cat",
    }
    await client.animal.search(searchTerm).then(response => {
      console.log('data')
      let petsData = response.data;
      setData(pets => [...pets, petsData.animals].flat());
    });
  }

  useEffect(() => {
    getD()
  }, [])
  return (
    <ScrollView style={styles.container}>
          {data.map ((e)=> (
              <Lob name={e.name} breed={e.breeds.primary} age={e.age} status={e.status} contact={e.contact.email} color={e.color} gender={e.gender} phone={e.contact.phone}/>
          ))}
    </ScrollView>
  );
}

export default Main;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'top',
    backgroundColor: '#BAE2DD'
  },
  
})