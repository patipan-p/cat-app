import { StyleSheet, Text, View, Button,Image, ScrollView, TouchableHighlight, TouchableOpacity, Platform, TextInput} from 'react-native';
import React, { useState, useEffect, Component } from 'react';

import _ from "lodash";


import * as ImagePicker from 'expo-image-picker';

import { firebase } from '@firebase/app';
import firestore from '../../../Firestore';
import '@firebase/auth';
import '@firebase/storage';

import ReactDOM from 'react-dom';
//import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
//import { Carousel } from 'react-responsive-carousel';

//import navigator
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

//create bottom tab
const Tab = createBottomTabNavigator();
//create stack
const Stack = createStackNavigator();


import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons';

function Mp({navigation}){

  const [user, setCuser] = useState('')
  const [name, setName] = useState('');
  const [image, setImage] = useState('');

  async function upImg(){
    const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    allowsEditing: true,
    aspect: [4, 3],
    quality: 1,
    });
    if (!result.cancelled) {
    console.log(result);
    const response = await fetch(result.uri);
    const blob = await response.blob();

    var storageRef = firebase.storage().ref();
    var picsRef = storageRef.child(user.uid + ".jpg");

    picsRef.put(blob).then((snapshot) => {
      console.log('uploaded');
      CheckLogin(); 
    }).catch((error) => console.log(error.message));
    }
  }

  async function saveP(){
    firebase.auth().onAuthStateChanged((user) => {
        let collRef = firestore.collection('user').doc(user.uid);
        collRef.set({
          name: name,
        });
    })
    alert('saved')
    navigation.reset({index: 0, routes: [{name : 'Main'}]});
  }

  async function getImage(){
    const result = await fetch(
      "https://api.thecatapi.com/v1/images/search" , {
      headers: {
        "Content-Type": "application/json",
        "x-api-key": "eee23f35-b735-4472-a661-1af69728d177 "}}
    )
    const json = await result.json();
    if (json.length > 0) {
      setImage(json[0].url)
    }
  }

  async function CheckLogin() {
      firebase.auth().onAuthStateChanged((user) => {
        if (user) {
          setCuser(user);

          const docRef = firestore.collection('user').doc(user.uid);

          docRef.get().then((doc) => {
            setName(doc.data().name);
          });

          let storageRef = firebase.storage().ref();
          let picRef = storageRef.child(user.uid + '.jpg').getDownloadURL();
          if (!picRef)
          {  getImage()}
          else
          {
            picRef.then((url) => setImage(url));
          }
        }
      });
    }

  useEffect(() => {
    CheckLogin();
  }, [])
  return (
    <View style={styles.container}>
      <View style={styles.upbar}>
      <Text style={{opacity: 0}}> Hello there </Text>
        <Image style={styles.image}source={{uri:image}} />
      </View>
      <View style={styles.username}>
        <TextInput placeholder={name} style={styles.textInput} onChangeText={setName}/>
      </View>
      <View style={{marginTop: 15}}>
      <View style={styles.btc} >
      <TouchableOpacity onPress={()=> upImg() } >
        <View style={styles.button}>
          <Text> Change Profile Picture </Text>
        </View>
      </TouchableOpacity>
      </View>
      </View>
      <View style={styles.btc2} >
      <TouchableOpacity onPress={()=> saveP()}>
        <View style={styles.buttonLong}>
          <Text> Save </Text>
        </View>
      </TouchableOpacity>
      <TouchableOpacity onPress={()=> navigation.goBack()}>
        <View style={styles.buttonLong}>
          <Text> Cancel </Text>
        </View>
      </TouchableOpacity>
      </View>
      
    </View>
  );
}

export default Mp;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    height: '100%',
    backgroundColor: '#BAE2DD'
  },
  image: {
      resizeMode: 'fit',
      width: '100%',
      height: '100%',
      borderRadius: 10,
  },
  upbar: {
    justifyContent: 'top',
    width: '100%',
    height: 200,
    backgroundColor: 'pink',
    padding: 10,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
  },
  btc: {
    paddingHorizontal: 10,
    paddingTop: 10,
    width: '100%',
    justifyContent: 'center'
  },
  btc2: { 
    width: '100%',
    paddingHorizontal: 10,
    flex: 1,
    justifyContent: 'flex-end',
    marginBottom: 5
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: 50,
    backgroundColor: '#FFFDD0',
    borderRadius: 8,
  },
  buttonLong: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: 50,
    backgroundColor: '#FFFDD0',
    borderRadius: 8,
    marginTop: 5
  },
  username: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15
  },
  username_name: {
    fontSize: 16,
    fontWeight: 'bold'
  },
  textInput: {
    padding: 10
  },
  
})