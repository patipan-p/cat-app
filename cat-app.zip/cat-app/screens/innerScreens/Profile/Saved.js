import { StyleSheet, Text, View,Image, ScrollView, TouchableHighlight, TouchableOpacity, Platform, TextInput, FlatList} from 'react-native';
import React, { useState, useEffect, Component } from 'react';

import _ from "lodash";



import { firebase } from '@firebase/app';
import firestore from '../../../Firestore';
import '@firebase/auth';

import Button from '@mui/material/Button';


//import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
//import { Carousel } from 'react-responsive-carousel';
import Gallery from 'react-grid-gallery';
//import navigator
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

//create bottom tab
const Tab = createBottomTabNavigator();
//create stack
const Stack = createStackNavigator();
import ImageGrid from '../../../components/ImageGrid'

import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons';

function Detail({route, navigation}){
  const [images, setData] = useState([])
  const [user, setUser] = useState(null)

  const { itemId } = route.params;
  const { item2 } = route.params;

  async function checkLogin(){
      firebase.auth().onAuthStateChanged((user) => {
        if (user){
          setUser(user);     
        }
      })
  }

  async function DelPic(){
    console.log(JSON.stringify(itemId))
    let collRef = firestore.collection('user').doc(user.uid).collection('saved').doc(itemId);

    await collRef.delete();
    alert('Image deleted ');
    navigation.reset({index: 1, routes: [{name : 'Main'}]});
  }

  useEffect(()=>{
    checkLogin()
  })

  return (
    <View style={styles.scr2}>
      <Image style={{width: '80%', height: '80%', resizeMode: 'contain',}} source={{uri: item2}} />
      <Button style={{marginTop: 10}} variant="contained" onClick={()=> DelPic()}>Delete</Button>
      <Button style={{marginTop: 5}} variant="contained" onClick={()=> navigation.goBack()}>Back</Button>
    </View>
  );
}

function Main2({navigation}){

  const [images, setData] = useState('')
  const [itit, setData2] = useState([])
  const [user, setUser] = useState(null)

  async function checkLogin(){
      firebase.auth().onAuthStateChanged((user) => {
        if (user){
          setUser(user);
          
          let collRef = firestore.collection('user').doc(user.uid).collection('saved');
          collRef.get().then((pds) => {
          const tempdoc = pds.docs.map((doc) => {
          return {id: doc.id, ...doc.data()};
        });
        console.log(tempdoc)
        setData([...images,...tempdoc.map((e)=> e.url)]);
        setData2(tempdoc)
        
      })
      }
      });
  }
  useEffect(() => {
    checkLogin()
  }, [])

  return (
    
    <ScrollView style={styles.scr}>
      <FlatList
        data={itit}
        renderItem={(item) => {    
        return <TouchableOpacity onPress={() => {navigation.navigate('Saved', {
            screen: 'Detail',
            params: { itemId: item.item.id, item2: item.item.url},
            }) }}>
                <ImageGrid pic={item.item.url}/>
               </TouchableOpacity>
        }}
        numColumns={3}
      />
    </ScrollView>
  );
}

function mainp({navigation}){
  return(
    <Stack.Navigator screenOptions={{
        headerShown: false
        }}>
        <Stack.Screen name="Main" component={Main2}/>
        <Stack.Screen name="Detail" component={Detail}/>
    </Stack.Navigator>   
  )
}

export default mainp;

const styles = StyleSheet.create({
  scr: {
    flex: 1,
    backgroundColor: '#BAE2DD'
  },
  scr2: {
    backgroundColor: '#BAE2DD',
    width: '100%',
    height: '100%',
    alignItems: 'center'
  },

})