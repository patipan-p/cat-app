import { StyleSheet, Text, View, Button,Image, ScrollView, TouchableHighlight, TouchableOpacity, Platform, TextInput} from 'react-native';
import React, { useState, useEffect } from 'react';

import _ from "lodash";

import { firebase } from '@firebase/app';
import firestore from '../../Firestore';
import '@firebase/auth';
import '@firebase/storage';

//import navigator
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

//create bottom tab
const Tab = createBottomTabNavigator();
//create stack
const Stack = createStackNavigator();

import Main from './HomeScreens/Main'
import Hotel from './HomeScreens/Hotel'
import Store from './HomeScreens/Store'
import Adopt from './HomeScreens/Adopt'
import Random from './HomeScreens/Gallery'


import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons';

function home2({navigation}){
  
  return (
    <View style= {styles.container}>
        <Stack.Navigator screenOptions={{
    headerShown: false
  }}>
        <Stack.Screen name="Main" component={Main}/>
        <Stack.Screen name="Hotel" component={Hotel}/>
        <Stack.Screen name="Cafe" component={Store}/>
        <Stack.Screen name="Adoption" component={Adopt}/>
        <Stack.Screen name="Random" component={Random}/>
        </Stack.Navigator>   
    </View>
  );
}

export default home2;

const styles = StyleSheet.create({
  container: {
    flex: 1
  }
})