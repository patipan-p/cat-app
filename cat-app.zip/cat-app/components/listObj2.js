import * as React from 'react';
import { Text, View, StyleSheet, Image, Table } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

export default function Breed(props) {
    return (
        <View style={styles.container}>
            <Text style={styles.header}>Name: {props.name}</Text>
            <Text style={styles.normal}>Gender: {props.gender}</Text>
            <Text style={styles.normal}>Color: {props.color}</Text>
            <Text style={styles.normal}>Breeds: {props.breed}</Text>
            <Text style={styles.normal}>Age: {props.age}</Text>
            <Text style={styles.normal}>Status: {props.status}</Text>
            <Text style={styles.normal}>Contact: {props.contact} / {props.phone}</Text>
        </View>
    );
}


const styles = StyleSheet.create({
    
    container: {
      //justifyContent: 'flex-start',
      backgroundColor: '#F8FFDE',
      margin: 8,
      height: 'auto',
      borderRadius: 10,
      padding: 10
    },
    image: {
      resizeMode: 'cover',
      width: '100%',
      height: '100px',
      borderTopStartRadius: 5,
    },
    header: {
      fontWeight: 'bold',
      fontSize: '18'
    },
    normal: {
      fontSize: '14'
    }
    

    
  });
  