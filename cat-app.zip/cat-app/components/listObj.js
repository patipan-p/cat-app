import * as React from 'react';
import { Text, View, StyleSheet, Image, Table } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { FontAwesome } from '@expo/vector-icons';

export default function Breed(props) {
  const navigation = useNavigation();
    return (
        <View style={styles.container}>
            <Image style={styles.image}source={{uri:props.pic}} />
            <Text style={styles.header}>{props.name}</Text>
            <Text style={styles.address}>{props.address}</Text>
            <Text style={styles.header}><FontAwesome name="star" color={'yellow'} size={'10'} /> {props.rating}/5</Text>
            <Text style={{fontStyle: 'italic', opacity: '30', fontSize: 12, alignSelf: 'center'}} variant="outlined" > view in GoogleMap </Text>
        </View>
    );
}


const styles = StyleSheet.create({
    
    container: {
      //justifyContent: 'flex-start',
      backgroundColor: '#F8FFDE',
      margin: 8,
      height: 'auto',
      borderRadius: 5,
      padding: 5,
    },
    image: {
      resizeMode: 'contain',
      width: '100%',
      height: '100px',
      borderTopStartRadius: 5,
    },
    header: {
      fontWeight: 'bold',
      fontSize: '18'
    },
    address: {
      fontStyle: 'italic',
      fontSize: '14'
    }
    

    
  });
  