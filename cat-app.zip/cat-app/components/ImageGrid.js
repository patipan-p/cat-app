import * as React from 'react';
import { Text, View, StyleSheet, Image, Table } from 'react-native';
import Button from '@mui/material/Button';

import { FontAwesome } from '@expo/vector-icons';

export default function Breed(props) {
    return (
        <View style={styles.container}>
            <Image style={styles.image}source={{uri:props.pic}} />
        </View>
    );
}


const styles = StyleSheet.create({
    
    container: {
      margin: 5,
    },
    image: {
      resizeMode: 'fit',
      width: '100px',
      height: '100px',
      
    },
  
    
  });
  