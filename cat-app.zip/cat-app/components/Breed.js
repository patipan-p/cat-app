import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

export default function Breed(props) {
    return (
        <View style={styles.container}>
            <Image style={styles.image}source={{uri:props.pic}} />
            <Text style={styles.header}>{props.name}</Text>
        </View>
    );
}


const styles = StyleSheet.create({
    
    container: {
      //justifyContent: 'flex-start',
      backgroundColor: '#fff',
      margin: 8,
      height: 160,
      position: 'relative',
      overflow: 'hidden',
      borderRadius: 10
    },
    image: {
      resizeMode: 'cover',
      width: '100%',
      height: '100%'
    },
    header: {
    fontSize: 12,
    color: 'white',
    textAlign: 'center',
    position: 'absolute',
    fontWeight: 'bold',
    bottom: 10,
    left: 0,
    right: 0,
    height: 'fit-content',
    margin: 'auto',
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: {width: -1, height: 1},
    textShadowRadius: 10
    }

    
  });
  