import React, { useState, useEffect, Component } from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';


//import navigator
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

//create bottom tab
const Tab = createBottomTabNavigator();
//create stack
const Stack = createStackNavigator();

import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

//import screens
import  Login from "./screens/Login";
import  Register from "./screens/Register";
import  Forgot from "./screens/ForgotPassword";
import  Home from "./screens/HomeScreen";

export default function App() {
  return (
    <View style={styles.container}>
      <NavigationContainer>
        <Stack.Navigator screenOptions={{
    headerShown: false
  }}>
        <Stack.Screen name="login" component={Login}/>
        <Stack.Screen name="register" component={Register}/>
        <Stack.Screen name="forgot" component={Forgot}/>
        <Stack.Screen name="home" component={Home}/>
        </Stack.Navigator>
      </NavigationContainer>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'red',
    //paddingTop: Constants.statusBarHeight,
    //padding: 8,
  },
});
